package com.example.androidproj

import com.google.gson.annotations.SerializedName

data class BestSellerDto(
    @SerializedName("title") val title: String,
    @SerializedName("item") val bookList: List<Book> // Book 형태의 List
)