package com.example.androidproj

import androidx.room.*
import com.example.androidproj.Review


@Entity
data class Review(
    @PrimaryKey val id: Int?,
    @ColumnInfo(name = "review") val review: String?

)