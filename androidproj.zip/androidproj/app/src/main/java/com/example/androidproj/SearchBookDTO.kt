package com.example.androidproj

import com.google.gson.annotations.SerializedName

data class SearchBookDto(
    @SerializedName("title") val title: String,
    @SerializedName("item") val bookList: List<Book> // Book 형태의 List
)
