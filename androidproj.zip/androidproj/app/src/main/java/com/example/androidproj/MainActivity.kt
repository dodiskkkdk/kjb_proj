package com.example.androidproj

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.room.Room
import com.example.androidproj.BookAdapter
import com.example.androidproj.HistoryAdapter
import com.example.androidproj.BookService
import com.example.androidproj.BestSellerDto
import com.example.androidproj.Book
import com.example.androidproj.History
import com.example.androidproj.SearchBookDto
import com.example.androidproj.R
import com.example.androidproj.databinding.ActivityMainBinding


import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: BookAdapter
    private lateinit var bookService: BookService
    private lateinit var historyAdapter: HistoryAdapter
    private lateinit var db: AppDatabase

    var initTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)

        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        initBookRecyclerView()
        initHistoryRecyclerView()
        initSearchEditText()


        db = getAppDatabase(this)


        val retrofit = Retrofit.Builder()
            .baseUrl("https://book.interpark.com/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        bookService = retrofit.create(BookService::class.java)


        bookService.getBestSellerBooks(getString(R.string.interparkAPIKEY))
            .enqueue(object : Callback<BestSellerDto> {
                override fun onResponse(
                    call: Call<BestSellerDto>,
                    response: Response<BestSellerDto>
                ) {
                    //성공처리
                    if (response.isSuccessful.not()) {
                        Log.d("lee", "NOT SUCCESS")
                        return
                    }
                    response.body()?.let {
                        Log.d("lee", it.toString())

                        it.bookList.forEach { Book ->
                            Log.d("lee", Book.toString())
                        }

                        adapter.submitList(it.bookList)
                    }
                }

                override fun onFailure(
                    call: Call<BestSellerDto>,
                    t: Throwable
                ) {

                    Log.e(TAG, t.toString())
                }
            })
    }

    private fun search(keyword: String) {

        bookService.getBooksByName(getString(R.string.interparkAPIKEY), keyword)
            .enqueue(object : Callback<SearchBookDto> {
                override fun onResponse(
                    call: Call<SearchBookDto>,
                    response: Response<SearchBookDto>
                ) {

                    hideHistoryView()
                    saveSearchKeyword(keyword)

                    if (response.isSuccessful.not()) {
                        return
                    }


                    adapter.submitList(response.body()?.bookList.orEmpty())
                    adapter.notifyDataSetChanged()


                }

                override fun onFailure(
                    call: Call<SearchBookDto>,
                    t: Throwable
                ) {


                    hideHistoryView()

                }

            })

    }

    fun initBookRecyclerView() {


        adapter = BookAdapter(itemClickedListener = {
            val intent = Intent(this, DetailActivity::class.java)
            intent.putExtra("bookModel", it)

            startActivity(intent)
        })


        binding.bookRecyclerView.layoutManager = LinearLayoutManager(this)


        binding.bookRecyclerView.adapter = adapter
    }


    fun initHistoryRecyclerView() {


        historyAdapter = HistoryAdapter(historyDeleteClickedListener = {
            deleteSearchKeyword(it)
        })

        binding.historyRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.historyRecyclerView.adapter = historyAdapter

    }

    private fun initSearchEditText() {

        binding.searchEditText.setOnKeyListener { v, keyCode, event ->


            if (keyCode == KeyEvent.KEYCODE_ENTER && event.action == MotionEvent.ACTION_DOWN) {
                search(binding.searchEditText.text.toString())


                return@setOnKeyListener true
            }

            return@setOnKeyListener false

        }

        binding.searchEditText.setOnTouchListener { v, event ->
            var handled = false

            if (event.action == MotionEvent.ACTION_DOWN) {
                showHistoryView()

            }

            // 입력 완료 시 키보드 내림 기능 추가
            if (event.action == EditorInfo.IME_ACTION_DONE) {
                val inputMethodManager =
                    getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                inputMethodManager.hideSoftInputFromWindow(binding.searchEditText.windowToken, 0)
                handled = true
            }


            binding.searchEditText.setText(null)
            return@setOnTouchListener false
        }

    }

    private fun showHistoryView() {
        Thread {
            val keyword = db.historyDao().getAll().reversed()

            runOnUiThread {
                historyAdapter.submitList(keyword.orEmpty())
                binding.historyRecyclerView.isVisible = true
            }

        }.start()

    }

    private fun hideHistoryView() {
        binding.historyRecyclerView.isVisible = false
    }

    private fun saveSearchKeyword(keyword: String) {
        Thread {
            db.historyDao().insertHistory(History(null, keyword))
        }.start()
    }

    private fun deleteSearchKeyword(keyword: String) {
        Thread {
            db.historyDao().delete(keyword)
            showHistoryView()
        }.start()
    }

    companion object {
        private const val TAG = "MainActivity"
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (System.currentTimeMillis() - initTime > 3000) {
                Toast.makeText(this, "종료하려면 한 번 더 누르세요", Toast.LENGTH_SHORT).show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        finishAffinity();
        System.runFinalization();
        System.exit(0);

        return super.onKeyDown(keyCode, event)
    }
}

